package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SingleTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SingleTestApplication.class, args);
	}

}
