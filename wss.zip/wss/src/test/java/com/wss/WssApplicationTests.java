package com.wss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WssApplicationTests {

	@Test
	void contextLoads() {
	}

}
